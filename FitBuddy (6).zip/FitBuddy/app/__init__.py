"""
FitBuddy application package.
"""